# AdminLTE-RTL
AdminLTE-RTL version, [forked from almasaeed2010/AdminLTE](https://github.com/almasaeed2010/AdminLTE/)



## changes
1. Only link rtl css to html pages(remove Jquery-UI from rtl-pages).
2. Only change less files direction with rtl.


### html
1. add index-rtl.html
2. add index2-rtl.html
3. add start-rtl.html
4. add pages-rtl/*.html

----
### less
1. add less-rtl/*.less
2. add AdminLTE-RTL
3. add Bootstartp-rtl
4. remove goolge fonts add local font files(rtl pages)
5. remove Jquery-UI(rtl-pages)
